create database project;
use project;
-- drop table vehicle_registration;
create table Onwer
(
Onwer_CNIC int(16),
first_name varchar(100),
last_name varchar(100),
address varchar(100),
primary key(Onwer_CNIC)
);
create table vehicle_registration
(
registration_number varchar(50),
vehicle_type varchar(50),
colour varchar (50),
Onwer_CNIC int(16),
primary key(registration_number),
FOREIGN KEY (onwer_CNIC) REFERENCES Onwer(Onwer_CNIC)

);
create table  E_challan_record
(
challan_number int,
location varchar(50),
amount int,
r_number varchar(50),
primary key(challan_number),
foreign key(r_number) references vehicle_registration(registration_number)


);
create table Traffic_warden_Record
(
warden_id int,
first_name varchar(100),
last_name varchar(100),
warden_CNIC int,
C_number int,
primary key(warden_id),
foreign key (C_number) references E_challan_record(challan_number)
);
create table complain
(
complain_id int,
C_description varchar(200),
amount int,
warden_id int(16),
registration_number varchar(50),
primary key(complain_id),
foreign key(registration_number) references vehicle_registration(registration_number),
foreign key(warden_id) references Traffic_warden_Record(warden_id)


);